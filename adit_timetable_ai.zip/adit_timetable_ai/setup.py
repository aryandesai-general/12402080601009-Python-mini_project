from setuptools import setup, find_packages

setup(
    name="adit_timetable_ai",
    version="2.0.0",
    author="Desai Aryan M.",
    author_email="aryan.desai@adit.ac.in",
    description="Automated Academic Timetable Generation & Resource Allocation System using Constraint Satisfaction (CSP)",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "adit_timetable_ai": ["static/*", "static/assets/*"],
    },
    entry_points={
        "console_scripts": [
            "adit-timetable=adit_timetable_ai.main:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)

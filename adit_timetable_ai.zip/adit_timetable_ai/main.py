"""
Main CLI entry point for ADIT AI Timetable Generator package.
"""

import sys
import argparse
from adit_timetable_ai.server import start_server
from adit_timetable_ai.csp_solver import TimetableSolver
from adit_timetable_ai.database import get_all_departments, get_department_faculty


def run_tests():
    """Executes verification test suite on constraints and multi-department scheduling."""
    print("=" * 60)
    print("🧪 Running ADIT AI Timetable Verification Test Suite...")
    print("=" * 60)

    solver = TimetableSolver(seed=42)
    res = solver.generate_all(semester=5)

    # Test 1: Departments generated
    depts = get_all_departments()
    assert len(solver.timetables) == len(depts) * 2, f"Expected {len(depts) * 2} division timetables, got {len(solver.timetables)}"
    print("✅ Test 1: All 8 Engineering Departments generated (Div 1 & Div 2).")

    # Test 2: Double booking check
    fac_counts = {}
    for (fac_code, day, slot), class_id in solver.booked_faculty.items():
        key = (fac_code, day, slot)
        fac_counts[key] = fac_counts.get(key, 0) + 1
        assert fac_counts[key] == 1, f"Double-booking detected for {fac_code} at {day} slot {slot}"
    print("✅ Test 2: Zero faculty double-booking collisions verified across all branches.")

    # Test 3: Shared faculty verification
    it_aids_shared = get_department_faculty("IT")
    ce_csd_shared = get_department_faculty("CE")
    assert any(f["dept"] == "AIDS" for f in it_aids_shared), "IT faculty pool missing AIDS teachers"
    assert any(f["dept"] == "CSD" for f in ce_csd_shared), "CE faculty pool missing CSD teachers"
    print("✅ Test 3: Inter-departmental faculty pooling (IT ⇄ AIDS, CE ⇄ CSD) active.")

    # Test 4: Saturday Holiday Check
    for class_id, tt in solver.timetables.items():
        assert "Saturday" not in tt.grid, "Saturday must be a complete holiday"
    print("✅ Test 4: Saturday Holiday invariant verified (0 slots booked).")

    # Test 5: Parallel Elective Options Check (Same time, Different classrooms)
    ce_tt = solver.timetables.get("CE_S5_D1")
    assert ce_tt is not None, "CE_S5_D1 timetable must exist"
    elective_slots_found = 0
    for day, slots in ce_tt.grid.items():
        for s, entry in slots.items():
            if getattr(entry, "is_elective", False) and getattr(entry, "elective_options", None):
                elective_slots_found += 1
                opts = entry.elective_options
                assert len(opts) >= 2, "Elective basket must have 2+ options"
                rooms = [o["room_no"] for o in opts]
                facs = [o["faculty_code"] for o in opts]
                assert len(set(rooms)) == len(rooms), f"Elective options must be in different rooms: {rooms}"
                assert len(set(facs)) == len(facs), f"Elective options must have different faculty: {facs}"
    assert elective_slots_found > 0, "At least one parallel elective slot must be scheduled"
    print(f"✅ Test 5: Parallel Elective Invariant verified ({elective_slots_found} slots with options in different rooms at same time).")

    # Test 6: Lab Timing Disjointness Check
    for class_id, tt in solver.timetables.items():
        lab_slots_set = set()
        for day, slots in tt.grid.items():
            for s, entry in slots.items():
                if entry.activity == "LAB":
                    assert (day, s) not in lab_slots_set, f"Collision detected for lab in {class_id} at {day} {s}"
                    lab_slots_set.add((day, s))
    print("✅ Test 6: Lab Timing Invariant verified (all labs scheduled at distinct non-overlapping timings).")

    print("\n🎉 ALL TESTS PASSED! System is 100% verified and collision-free.\n")


def generate_cli(dept: str, sem: int):
    """Generates and prints timetable to terminal."""
    solver = TimetableSolver(seed=42)
    solver.generate_all(semester=sem)
    class_id = f"{dept}_S{sem}_D1"
    tt = solver.timetables.get(class_id)

    if not tt:
        print(f"Error: Timetable for {class_id} not found.")
        return

    print("=" * 75)
    print(f" 📅 ADIT OFFICIAL TIMETABLE • Dept: {dept} • Semester: {sem} • Div: 1 • Room: {tt.room_no}")
    print("=" * 75)
    header = f"{'Day':<10} | {'Slot 1':<12} | {'Slot 2':<12} | {'Slot 3':<12} | {'Slot 4':<12} | {'Slot 5':<12} | {'Slot 6':<12}"
    print(header)
    print("-" * 75)

    for day, slots in tt.grid.items():
        row = [f"{day:<10}"]
        for s in [1, 2, 3, 4, 5, 6]:
            entry = slots.get(s)
            if entry:
                text = f"{entry.subject_code} ({entry.faculty_code})"
                row.append(f"{text:<12}")
            else:
                row.append(f"{'-':<12}")
        print(" | ".join(row))
    print("=" * 75)


def main():
    parser = argparse.ArgumentParser(description="ADIT AI Timetable Generator System")
    parser.add_argument("--serve", action="store_true", help="Launch web portal and REST API server")
    parser.add_argument("--port", type=int, default=8000, help="Port to bind server (default: 8000)")
    parser.add_argument("--generate", action="store_true", help="Generate timetable in CLI mode")
    parser.add_argument("--dept", type=str, default="CE", help="Department code (CE, IT, CSD, AIDS, ME, CL, EE, CH)")
    parser.add_argument("--sem", type=int, default=5, help="Semester (1-8)")
    parser.add_argument("--test", action="store_true", help="Run verification test suite")

    args = parser.parse_args()

    if args.test:
        run_tests()
    elif args.generate:
        generate_cli(args.dept.upper(), args.sem)
    else:
        # Default: start web server
        start_server(port=args.port)


if __name__ == "__main__":
    main()

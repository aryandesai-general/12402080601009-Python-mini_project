"""
High-performance REST API and static web server using Python's standard library.
Zero external dependencies required out of the box!
"""

import json
import os
import mimetypes
from urllib.parse import urlparse, parse_qs
from http.server import HTTPServer, BaseHTTPRequestHandler
from .csp_solver import TimetableSolver
from .database import (
    get_all_departments,
    get_department_faculty,
    get_curriculum,
    get_rooms,
)

# Global solver instance
GLOBAL_SOLVER = TimetableSolver(seed=42)
LATEST_SOLUTION = GLOBAL_SOLVER.generate_all(semester=5)

STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")


class TimetableAPIHandler(BaseHTTPRequestHandler):
    """Handles HTTP requests for the AI Timetable Generator web portal and API."""

    def _set_headers(self, content_type="application/json", status=200):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_OPTIONS(self):
        self._set_headers(status=204)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        params = parse_qs(parsed.query)

        # ----------------- REST API ENDPOINTS -----------------
        if path == "/api/health":
            self._set_headers()
            self.wfile.write(json.dumps({"status": "ONLINE", "version": "2.0.0"}).encode())

        elif path == "/api/departments":
            self._set_headers()
            self.wfile.write(json.dumps(get_all_departments()).encode())

        elif path == "/api/faculty":
            dept = params.get("dept", ["CE"])[0]
            faculty = get_department_faculty(dept)
            self._set_headers()
            self.wfile.write(json.dumps(faculty).encode())

        elif path == "/api/curriculum":
            dept = params.get("dept", ["CE"])[0]
            sem = int(params.get("sem", [5])[0])
            curriculum = get_curriculum(dept, sem)
            self._set_headers()
            self.wfile.write(json.dumps(curriculum).encode())

        elif path == "/api/rooms":
            rooms = get_rooms()
            self._set_headers()
            self.wfile.write(json.dumps(rooms).encode())

        elif path == "/api/workload":
            workload = GLOBAL_SOLVER.get_workload_summary()
            self._set_headers()
            self.wfile.write(json.dumps(workload).encode())

        elif path == "/api/export_csv":
            dept = params.get("dept", ["CE"])[0]
            sem = int(params.get("sem", [5])[0])
            div = int(params.get("div", [1])[0])
            class_id = f"{dept}_S{sem}_D{div}"
            tt = GLOBAL_SOLVER.timetables.get(class_id)

            if not tt:
                self._set_headers(status=404)
                self.wfile.write(json.dumps({"error": "Timetable not found"}).encode())
                return

            # Build CSV
            lines = ["Day,Slot 1 (10:30-11:30),Slot 2 (11:30-12:30),Slot 3 (01:15-02:15),Slot 4 (02:15-03:15),Slot 5 (03:30-04:30),Slot 6 (04:30-05:30)"]
            for day, slots in tt.grid.items():
                row = [day]
                for s in [1, 2, 3, 4, 5, 6]:
                    entry = slots.get(s)
                    if entry:
                        row.append(f'"{entry.subject_code} - {entry.faculty_name} ({entry.room_no})"')
                    else:
                        row.append('""')
                lines.append(",".join(row))

            csv_data = "\n".join(lines)
            self.send_response(200)
            self.send_header("Content-Type", "text/csv")
            self.send_header("Content-Disposition", f'attachment; filename="timetable_{class_id}.csv"')
            self.end_headers()
            self.wfile.write(csv_data.encode())

        # ----------------- STATIC ASSETS & WEB PAGES -----------------
        else:
            rel_path = path.lstrip("/")
            if not rel_path:
                rel_path = "index.html"

            file_path = os.path.join(STATIC_DIR, rel_path)
            if not os.path.isfile(file_path):
                # Fallback to project root directory
                proj_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                alt_path = os.path.join(proj_root, rel_path)
                if os.path.isfile(alt_path):
                    file_path = alt_path
                else:
                    alt_path2 = os.path.join(os.path.dirname(os.path.abspath(__file__)), rel_path)
                    if os.path.isfile(alt_path2):
                        file_path = alt_path2

            if os.path.isfile(file_path):
                mime, _ = mimetypes.guess_type(file_path)
                self._set_headers(content_type=mime or "application/octet-stream")
                with open(file_path, "rb") as f:
                    self.wfile.write(f.read())
            else:
                self._set_headers(status=404)
                self.wfile.write(json.dumps({"error": f"File {path} not found"}).encode())

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path

        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length).decode() if content_length > 0 else "{}"
        try:
            payload = json.loads(body)
        except Exception:
            payload = {}

        if path == "/api/generate":
            sem = int(payload.get("semester", 5))
            seed = int(payload.get("seed", 42))
            solver = TimetableSolver(seed=seed)
            result = solver.generate_all(semester=sem)
            global GLOBAL_SOLVER, LATEST_SOLUTION
            GLOBAL_SOLVER = solver
            LATEST_SOLUTION = result
            self._set_headers()
            self.wfile.write(json.dumps(result).encode())

        elif path == "/api/validate_slot":
            dept = payload.get("dept", "CE")
            day = payload.get("day", "Monday")
            slot = int(payload.get("slot", 1))
            fac_code = payload.get("faculty_code", "02")
            room_no = payload.get("room_no", "213")
            class_id = payload.get("class_id", "CE_S5_D1")

            val_res = GLOBAL_SOLVER.validate_manual_edit(
                dept_code=dept,
                day=day,
                slot=slot,
                faculty_code=fac_code,
                room_no=room_no,
                current_class_id=class_id
            )
            self._set_headers()
            self.wfile.write(json.dumps(val_res).encode())

        else:
            self._set_headers(status=404)
            self.wfile.write(json.dumps({"error": "Endpoint not found"}).encode())


def start_server(host="0.0.0.0", port=8000):
    """Starts the Python HTTP server serving both Web UI and REST API."""
    HTTPServer.allow_reuse_address = True
    server = None
    for p in [port, port + 1, port + 80, 8080]:
        try:
            server = HTTPServer((host, p), TimetableAPIHandler)
            port = p
            break
        except OSError as e:
            if p == 8080:
                print(f"Error: Could not bind to port {port} or fallback ports: {e}")
                return
            continue

    print("=" * 70)
    print(" 🎓 ADIT AI Timetable Generation Web Server & REST API")
    print(f" • Running at: http://localhost:{port}/")
    print(f" • API Health: http://localhost:{port}/api/health")
    print("=" * 70)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping server...")
        server.server_close()

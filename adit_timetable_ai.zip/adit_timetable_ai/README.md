# 🎓 ADIT AI Timetable Generator & Multi-Department Scheduling System
### A D Patel Institute of Technology (ADIT) • The Charutar Vidya Mandal (CVM) University
**Software Engineering Capstone Project**  
- **Author**: Desai Aryan M.  
- **Enrollment Number**: EN. No. 12402080601009  
- **Department**: Information Technology / Computer Engineering  

---

## 🌟 Overview

The **ADIT AI Timetable Generator** is an automated academic scheduling package built using Python and Constraint Satisfaction (CSP) heuristics. It solves multi-departmental faculty allocation, equitable workload leveling, and room contention across 8 engineering disciplines with provably **zero double-booking collisions**.

### 🏛️ Core Institutional Constraints Solved:
1. **Academic Week**: 5-Day teaching schedule (Monday to Friday). **Saturday & Sunday are strict full-day holidays**.
2. **Theory Courses**: Exactly **3 lectures per week** per theory subject scheduled on distinct days.
3. **Laboratory Sessions**: Exactly **1 lab per week** in a contiguous 2-period block (40 student capacity partitioned into Batches A & B / C & D).
4. **Classroom Commonality**: Lecture classrooms (80 Capacity) are **pooled across all departments**. Laboratories are discipline-dedicated.
5. **Inter-Departmental Faculty Resource Sharing**:
   - **Information Technology (IT) ⇄ Artificial Intelligence & Data Science (AI & DS)** share a unified faculty pool.
   - **Computer Engineering (CE) ⇄ Computer Science & Design (CSD)** share a unified faculty pool.
   - No double-booking across shared departments.
   - **In-Between Free Lecture Fallback**: If a professor is occupied in a partner department, the scheduler automatically designates the in-between period as a **Free Lecture (Self-Study / Digital Library)**.
6. **Equitable Workload Leveling**: Balances teaching load to **12–15 hours / week** per faculty member while prioritizing professor subject preferences (1st choice mandatory, 2nd–5th optional).

---

## 📁 Package Structure

```
adit_timetable_ai/
│
├── __init__.py          # Package initialization & exports
├── config.py            # Academic constants, time periods, and sharing pairs
├── models.py            # Dataclasses (Course, Faculty, Room, PeriodEntry, Timetable)
├── database.py          # Normalized ADIT database (all faculty from adit.ac.in, curriculums, rooms)
├── csp_solver.py        # Constraint Satisfaction Problem (CSP) solver engine
├── server.py            # High-performance REST API and web server (zero dependencies)
├── main.py              # Main CLI entry point
├── run.py               # Quick runner script
├── setup.py             # Standard Python package setup
├── requirements.txt     # Optional dependency specs
├── README.md            # Complete project documentation
└── static/              # Web application and static assets
    ├── index.html       # Full interactive web application with Live Slot Editor
    └── assets/          # Logos & visual branding
        ├── logos.js
        ├── cvm_logo.jpg
        └── adit_logo.webp
```

---

## 🚀 Quick Start Guide

### 1. Zero-Install Instant Launch (Built-in Python Standard Library)
The application requires **Python 3.8+** with **zero external dependencies**:

```bash
# Launch the web application & REST API server
python3 run.py
```
Open your browser and navigate to:
- **Interactive Timetable Application**: [http://localhost:8000/](http://localhost:8000/)
- **API Health Check**: [http://localhost:8000/api/health](http://localhost:8000/api/health)

### 2. Run Verification Test Suite
Verifies 100% collision elimination, Saturday holiday invariant, and inter-departmental pooling:
```bash
python3 run.py --test
```

### 3. Generate Timetables via CLI
Generate and view department schedules directly in your terminal:
```bash
# Generate Computer Engineering Sem 5
python3 run.py --generate --dept CE --sem 5

# Generate Information Technology Sem 5
python3 run.py --generate --dept IT --sem 5

# Generate AI & Data Science Sem 5
python3 run.py --generate --dept AIDS --sem 5
```

---

## 📡 REST API Reference

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/health` | Service health status |
| `GET` | `/api/departments` | List of all 8 engineering departments |
| `GET` | `/api/faculty?dept=CE` | Faculty list with designations, qualifications & sharing tags |
| `GET` | `/api/curriculum?dept=CE&sem=5` | Semester courses with L-T-P-C credits |
| `GET` | `/api/rooms` | Classrooms (80 Cap) & Laboratories (40 Cap) |
| `GET` | `/api/workload` | Faculty teaching hour balance dashboard |
| `POST` | `/api/generate` | Run multi-department CSP scheduler (payload: `{"semester": 5}`) |
| `POST` | `/api/validate_slot` | Real-time conflict validation for manual slot editing |
| `GET` | `/api/export_csv?dept=CE&sem=5&div=1` | Download timetable in CSV format |

---

## 📜 License & Accreditation
Developed for **A D Patel Institute of Technology (ADIT)**, constituent college of **The Charutar Vidya Mandal (CVM) University**.  
Licensed under the **MIT License**.
